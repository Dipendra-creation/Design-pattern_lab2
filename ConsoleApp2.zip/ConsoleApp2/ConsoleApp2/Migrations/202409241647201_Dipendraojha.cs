﻿namespace ConsoleApp2.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Dipendraojha : DbMigration
    {
        public override void Up()
        {
          

            CreateTable(
               "dbo.categories",
               c => new
               {
                   CategoryId = c.Int(nullable: false),
                   CategoryName = c.String(maxLength: 50, unicode: false),
                   Description = c.String(maxLength: 500, unicode: false),
               })
               .PrimaryKey(t => t.CategoryId);

        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Produts", "SupplierId", "dbo.Suppliers");
            DropForeignKey("dbo.InventoryTransaction", "ProductId", "dbo.Produts");
            DropIndex("dbo.Produts", new[] { "SupplierId" });
            DropIndex("dbo.InventoryTransaction", new[] { "ProductId" });
            DropTable("dbo.Suppliers");
            DropTable("dbo.Produts");
            DropTable("dbo.InventoryTransaction");
        }
    }
}
